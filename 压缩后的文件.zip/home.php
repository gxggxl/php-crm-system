<div class="container">
	<div class="inner cover well">
		<h1 class="cover-heading text-center">客户管理系统</h1>
		<p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique rem veniam assumenda fugit illo delectus earum? Tenetur consequuntur asperiores ullam voluptates at voluptas blanditiis aut itaque suscipit in facilis alias!</p>
		<p class="lead text-center">
			<a href="login.php" class="btn btn-lg btn-default">Login</a>
		</p>
	</div>
</div>