<?php include 'head.php'; ?>
<?php include 'home.php'; ?>
<?php include 'footer.php'; ?>