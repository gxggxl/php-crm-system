	
	<footer class="navbar navbar-static-bottom footer">
		<!-- navbar-fixed-bottom 这个类可以使其固定在网页底部，并且不随网页滚动 -->
		<!-- navbar-static-bottom 如果需要随网页滚动，则使用这个类 -->
		<div class="container">
			<div>
				<div>
					<div class="text-center">
						<span>Copyright &copy; 2020 
							<a href="http://beian.miit.gov.cn/" target="_blank">桂ICP备18002684号-3</a>&nbsp;|&nbsp;
							<a href="https://gxusb.com" target="_blank">Blog</a>&nbsp;|&nbsp;
							<a href="https://github.com/gxggxl/php-crm-system" target="_blank">项目开源地址</a>
						</span>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
	</body>

</html>