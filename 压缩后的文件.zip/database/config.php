<?php
/*
 * @Author       : gxggxl
 * @E-mail       : gxggxl@qq.com
 * @Date         : 2020-09-19 23:16:07
 * @LastEditTime : 2020-09-27 20:26:17
 * @FilePath     : /php-crm-system/database/config.php
 */

# 数据库配置项
$dbinfo = array(
	'host'     => 'localhost',
	'port'     => '3306 ',
	'user'     => 'test',
	'password' => '123456',
	'dbname'   => 'test',
	'charset'  => 'utf8',
);

?>