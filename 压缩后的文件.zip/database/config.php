<?php
/*
 * @Author       : gxggxl
 * @E-mail       : gxggxl@qq.com
 * @Date         : 2020-09-19 23:16:07
 * @LastEditTime : 2020-09-27 20:26:17
 * @FilePath     : /php-crm-system/database/config.php
 */

// # *必填，数据库名称
// define("DBNAME", "test");
// # *必填，数据库主机名
// define("HOSTNAME", "localhost");
// # *必填，数据库用户名
// define("USERNAME", "root");
// # *必填，数据库密码
// define("PASSWORD", "");
// # 默认，数据库端口
// define("PORT", "3306");
// # 默认，编码格式
// define("CHARSET", "utf8");

# 数据库配置项
$dbinfo = array(
    'host' => 'localhost',
    'port' => '3306 ',
    'user' => 'test',
    'password' => '123456',
    'dbname' => 'test',
    'charset' => 'utf8'
);
?>